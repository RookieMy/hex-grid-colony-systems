using System.Runtime.CompilerServices;
using UnityEngine;

public class BuildingConfig : MonoBehaviour
{
    [Header("Kimlik")]
    public BuildingType buildingType;
    public BuildingCategory buildingCategory;

    [Header("Maliyet")]
    public int costMetal = 10;
    public int costIce = 0;
    public int costWater = 0;
    public int costOre = 0;

    [Header("Enerji")]
    public float energyProduction = 0f;
    public float energyConsumption = 0f;

    [Header("�retim D�ng�s� (per one tick)")]
    public int oreToMetalPerTick = 0;
    public int iceToWaterPerTick = 0;
    public int oreExtractionPerTick = 0;
    public int iceExtractionPerTick = 0;

    [Header("Yerle�im �artlar�")]
    public bool requiresFlatTile = false;
    public bool onlyOnRock = false;
    public bool onlyOnIce = false;

    [Header("Terraform D�ng�s� (per one tick)")]
    [Tooltip("Bu bina her tick s�cakl��� ka� �C artt�r�r/azalt�r")]
    public float temperatureDeltaPerTick = 0f;

    [Tooltip("Bu bina her tick atmosfer bas�nc�n� ka� kPa de�i�tirir")]
    public float pressureDeltaPerTick = 0f;

    [Tooltip("Bu bina her tick O2 fraksiyonunu ka� birim de�i�tirir (�r: 0.0001)")]
    public float oxygenDeltaPerTick = 0f;

}
